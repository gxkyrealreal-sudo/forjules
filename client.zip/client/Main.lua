local ESX = exports["es_extended"]:getSharedObject()
local PlayerData = {}
local sivedestocazzodihud = true
local Dentroilcazzodiveicolo = false
local huddelcazzostartato = false
local halacintura = false
local PlayerLoaded = false
local HUDBlocked = true  -- Blocca HUD all'inizio

-- Variabili per fame, sete e stress
local hunger = 100
local thirst = 100
local stress = 0

-- Variabili per tenere traccia dello stato multi-character
local isInMultiChar = false
local characterSpawned = false

-- RILEVAMENTO MULTI-CHARACTER (esx_identity / esx_multicharacter)
CreateThread(function()
    -- Controlla se esiste l'evento del multi-character
    while true do
        Wait(1000)
        
        -- Se l'HUD è bloccato e non siamo ancora spawnati
        if HUDBlocked and not characterSpawned then
            -- Nascondi HUD forzatamente
            SendNUIMessage({
                action = "Visible",
                data = false
            })
            DisplayRadar(false)
        end
        
        -- Se siamo in multi-character (rilevato dalla schermata di selezione)
        if GetResourceState("esx_multicharacter") == "started" then
            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)
            
            -- Se il ped è alla posizione del multi-character o ha 0 di salute
            if (coords.x == 0 and coords.y == 0 and coords.z == 0) then
                isInMultiChar = true
                HUDBlocked = true
                characterSpawned = false
                huddelcazzostartato = false
                
                -- Nascondi HUD completamente
                SendNUIMessage({
                    action = "Visible",
                    data = false
                })
                DisplayRadar(false)
            else
                isInMultiChar = false
            end
        end
    end
end)

local function InitializeHUD()
    -- sicurezza
    if huddelcazzostartato then return end

    HUDBlocked = false

    -- setup minimappa (tutto il tuo blocco)
    local defaultAspectRatio = 1920 / 1080
    local resolutionX, resolutionY = GetActiveScreenResolution()
    local aspectRatio = resolutionX / resolutionY
    local minimapOffset = 0

    if aspectRatio > defaultAspectRatio then
        minimapOffset = ((defaultAspectRatio - aspectRatio) / 3.6) - 0.008
    end

    RequestStreamedTextureDict("squaremap", false)
    while not HasStreamedTextureDictLoaded("squaremap") do
        Wait(100)
    end

    SetMinimapClipType(0)
    AddReplaceTexture("platform:/textures/graphics", "radarmasksm", "squaremap", "radarmasksm")

    SetMinimapComponentPosition("minimap", "L", "B", 0.007 + minimapOffset, -0.053, 0.207, 0.200)

    DisplayRadar(false)

    -- attiva HUD
    SendNUIMessage({
        action = "Visible",
        data = true
    })

    SendNUIMessage({
        action = "Id",
        data = GetPlayerServerId(PlayerId())
    })

    huddelcazzostartato = true
end

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
    PlayerLoaded = true

    -- aspetta spawn reale
    Wait(3000)

    InitializeHUD()
end)

-- Evento per il respawn (dopo la morte)
RegisterNetEvent('esx:onPlayerSpawn')
AddEventHandler('esx:onPlayerSpawn', function()
    Wait(2000)
    
    -- Controlla se siamo ancora in multi-character
    if isInMultiChar then
        return
    end
    
    characterSpawned = true
    HUDBlocked = false
    
    -- Riavvio HUD
    if not huddelcazzostartato then
        SendNUIMessage({
            action = "Visible",
            data = true
        })
        
        SendNUIMessage({
            action = "Id",
            data = GetPlayerServerId(PlayerId())
        })
        
        huddelcazzostartato = true
    end
end)

-- Evento per quando il personaggio viene ucciso (blocca HUD temporaneamente)
RegisterNetEvent('esx:onPlayerDeath')
AddEventHandler('esx:onPlayerDeath', function()
    -- NON bloccare HUD
    -- lascia tutto attivo
end)

-- Evento corretto per ricevere gli aggiornamenti da esx_status (via esx_basicneeds)
RegisterNetEvent('esx_status:OnTick')
AddEventHandler('esx_status:OnTick', function(statusName, value, percent)
    -- Ignora aggiornamenti se HUD bloccato
    if HUDBlocked then return end
    
    local status = tostring(statusName)
    local amount = math.floor(percent)
    
    if status == "hunger" then
        hunger = amount
    elseif status == "thirst" then
        thirst = amount
    elseif status == "stress" then
        stress = amount
    end
end)

function ToggleSeatbelt()
    Wait(1000)
    halacintura = not halacintura
    
    TriggerServerEvent("InteractSound_SV:PlayOnSource", "cintura", 1.25)
end

RegisterCommand('/toggleseatbelt', function()
    if IsPedInAnyVehicle(PlayerPedId(), false) then
        local class = GetVehicleClass(GetVehiclePedIsUsing(PlayerPedId()))
        if class ~= 8 and class ~= 13 and class ~= 14 then
            ToggleSeatbelt()
        end
    end
end, false)

RegisterKeyMapping('/toggleseatbelt', 'Toggle Seatbelt', 'keyboard', 'B')

CreateThread(function()
    while true do
        Wait(0)
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) and halacintura then
            DisableControlAction(0, 75, true) 
            if IsDisabledControlJustPressed(0, 75) then
                ESX.ShowNotification("Levati la cintura prima di scendere dal veicolo")
            end
        end
    end
end)

local function SendHUDMessage(action, data)
    -- Non inviare messaggi se HUD bloccato o non ancora inizializzato
    if HUDBlocked then return end
    
    SendNUIMessage({
        action = action,
        data = data
    })
end

local function stomotoredelcazzoerottoono(vehicle)
    return GetVehicleEngineHealth(vehicle) < 300.0
end

local function Aggiornafiglioditroia()
    if HUDBlocked or not PlayerLoaded or not huddelcazzostartato then return end
    if not PlayerData or not huddelcazzostartato then return end
    
    local ped = PlayerPedId()
    local health = GetEntityHealth(ped) - 100
    local armor = GetPedArmour(ped)
   
    health = math.max(0, math.min(100, health))
    
    local stamina = math.floor(100 - GetPlayerSprintStaminaRemaining(PlayerId()))
    local oxygen = math.floor(GetPlayerUnderwaterTimeRemaining(PlayerId()) * 10)
    
    SendHUDMessage("Status", {
        health = health,
        armour = armor,
        hunger = hunger,
        water = thirst,
        stress = stress,
        stamina = stamina,
        oxygen = oxygen,
        voice = GetVoiceRange(),
        talking = NetworkIsPlayerTalking(PlayerId())
    })
    
    SendHUDMessage("Id", GetPlayerServerId(PlayerId()))
end

local talkRange = 30

RegisterNetEvent('pma-voice:setTalkingMode', function(range)
    if range == 1 then
        talkRange = 33   -- Sussurra
    elseif range == 2 then
        talkRange = 60   -- Normale
    elseif range == 3 then
        talkRange = 90  -- Alta voce
    else
        talkRange = 6.0
    end
end)

function GetVoiceRange()
    return talkRange
end

local civici = {}
local civiciCaricati = false

local function CaricaCivici()
    if civiciCaricati then return end
    
    local resourceName = GetCurrentResourceName()
    local civiciData = LoadResourceFile(resourceName, 'json/civici.json')
    
    if civiciData then
        civici = json.decode(civiciData)
        civiciCaricati = true
        print('Caricati ' .. #civici .. ' civici')
    else
        print('Errore nel caricamento dei civici')
    end
end

local function TrovaCivicoVicinoNegro(playerX, playerY)
    if not civiciCaricati or #civici == 0 then
        return nil
    end
    
    local distanzaMinima = math.huge
    local civicoVicino = nil
    
    for i = 1, #civici do
        local civico = civici[i]
        local distanza = math.sqrt((playerX - civico.x)^2 + (playerY - civico.y)^2)
        
        if distanza < distanzaMinima then
            distanzaMinima = distanza
            civicoVicino = civico
        end
    end
    
    return civicoVicino
end

local function GetNearestCivico(x, y)
    if not civiciCaricati then
        CaricaCivici()
    end

    local targetX = x
    local targetY = y

    if type(targetX) ~= 'number' or type(targetY) ~= 'number' then
        local coords = GetEntityCoords(PlayerPedId())
        targetX = coords.x
        targetY = coords.y
    end

    local civicoVicino = TrovaCivicoVicinoNegro(targetX, targetY)
    if not civicoVicino then
        return nil
    end

    return {
        code = civicoVicino.code,
        x = civicoVicino.x,
        y = civicoVicino.y
    }
end

exports("GetNearestCivico", GetNearestCivico)

local function Aggiornaposizionenegrodimerda()
    if HUDBlocked or not huddelcazzostartato then return end
    
    if not civiciCaricati then
        CaricaCivici()
    end
    
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    
    if vehicle and vehicle ~= 0 then
        local coords = GetEntityCoords(ped)
        local streetHash, crossingHash = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
        local streetName = GetStreetNameFromHashKey(streetHash)
        local crossingName = GetStreetNameFromHashKey(crossingHash)
        local zone = GetNameOfZone(coords.x, coords.y, coords.z)
        
        local civicoVicino = TrovaCivicoVicinoNegro(coords.x, coords.y)
        local crossDisplay = '104' 
        
        if civicoVicino then
            crossDisplay = civicoVicino.code
        end
        
        SendHUDMessage("Location", {
            show = true,
            city = GetLabelText(zone),
            street = streetName,
            cross = crossDisplay
        })
    else
        SendHUDMessage("Location", {
            show = false
        })
    end
end

function luciaccesedioporcocihomesso20min(vehicle)
    if vehicle and vehicle ~= 0 then
        local lightsOn, luciaccese = GetVehicleLightsState(vehicle)
       
        if luciaccese == 1 then
            return true
        else 
            return false
        end
    end
    return false
end

local function Aggiornadatanegrodimerdafrocio()
    if HUDBlocked or not huddelcazzostartato then return end
    
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    
    if vehicle and vehicle ~= 0 then
        if not Dentroilcazzodiveicolo then
            Dentroilcazzodiveicolo = true
            veicolonigga = vehicle
            cinturaon = false
            
            DisplayRadar(true)
        end
        
        local velocita = math.floor(GetEntitySpeed(vehicle) * 3.6)
        local rpm = GetVehicleCurrentRpm(vehicle) * 100
        local fuel = GetVehicleFuelLevel(vehicle)
        local gear = GetVehicleCurrentGear(vehicle)
        local luci = luciaccesedioporcocihomesso20min(vehicle)
        local nitro = false
        
        local marciadelporcodio = 'N'
        if velocita > 0 then
            if gear == 0 then
                marciadelporcodio = 'R'
            else
                marciadelporcodio = gear
            end
        end
        
        SendHUDMessage("Vehicle", {
            show = true,
            speed = velocita,
            rpm = math.floor(rpm),
            fuel = math.floor(fuel),
            gear = marciadelporcodio,
            engine = stomotoredelcazzoerottoono(vehicle),
            light = luci,
            belt = halacintura,
            nitro = nitro,
        })
    else
        SendHUDMessage("Vehicle", {
            show = false
        })
        
        if Dentroilcazzodiveicolo then
            Dentroilcazzodiveicolo = false
            veicolonigga = nil
            cinturaon = false
            
            DisplayRadar(false)
        end
    end
end

CreateThread(function()
    while not PlayerLoaded do
        Wait(100)
    end

    while HUDBlocked or not huddelcazzostartato do
        Wait(100)
    end

    SendNUIMessage({
        action = "Vehicle",
        data = { show = false }
    })

    SendNUIMessage({
        action = "Id",
        data = GetPlayerServerId(PlayerId())
    })

    while true do
        Wait(250)

        if PlayerLoaded and not HUDBlocked and huddelcazzostartato and sivedestocazzodihud then
            Aggiornafiglioditroia()
            Aggiornaposizionenegrodimerda()
            Aggiornadatanegrodimerdafrocio()
        end
    end
end)

CreateThread(function()
    Wait(1000)
    while true do
        Wait(1000)
        
        if huddelcazzostartato and not HUDBlocked and PlayerLoaded then
            SetRadarZoom(1150)
            
            local ped = PlayerPedId()
            local dentroilporcodio = IsPedInAnyVehicle(ped, false)
            
            if dentroilporcodio then
                DisplayRadar(true)  
            else
                DisplayRadar(false)
            end
        end
    end
end)

RegisterNUICallback('hudReady', function(data, cb)
    cb('ok')
end)

RegisterCommand('hud', function()
    if HUDBlocked then
        ESX.ShowNotification("Hud non disponibile durante la selezione del personaggio o prima dello spawn")
        return
    end
    
    sivedestocazzodihud = not sivedestocazzodihud
    SendHUDMessage("Visible", sivedestocazzodihud)
end)

-- Comando di debug per testare i valori
RegisterCommand('teststatus', function()
    if HUDBlocked then
        ESX.ShowNotification("Hud non disponibile durante la selezione del personaggio o prima dello spawn")
        return
    end
    
    ESX.ShowNotification(("Fame: %s%% | Sete: %s%% | Stress: %s%%"):format(hunger, thirst, stress))
    print(("Hunger: %s, Thirst: %s, Stress: %s"):format(hunger, thirst, stress))
end)

-- Nascondi HUD di GTA
CreateThread(function()
    Wait(1000)

    DisplayCash(false)
    
    while true do
        Wait(0)

        HideHudComponentThisFrame(3) -- cash
        HideHudComponentThisFrame(4) -- bank
        HideHudComponentThisFrame(2) -- weapon wheel cash

        HideHudComponentThisFrame(7) -- area name
        HideHudComponentThisFrame(9) -- street name
        HideHudComponentThisFrame(6) -- vehicle name
    end
end)